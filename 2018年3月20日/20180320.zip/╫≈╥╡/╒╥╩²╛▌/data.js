var arr = ['100px', 'abc' - 6, [], -98765, 34, -2, 0, '300', , function() {
    alert(1);
}, null, document, [], true, '200px' - 30, '23.45元', 5, Number('abc'), function() {
    alert(3);
}, 'xyz' - 90];