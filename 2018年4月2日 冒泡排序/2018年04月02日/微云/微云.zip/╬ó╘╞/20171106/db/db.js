/**
 * 数据
 */

const db = {
  '0': {
    id: 0,
    name: '根目录'
  },
  '1': {
    id: 1,
    pId: 0,
    name: '电影'
  },
  '2': {
    id: 2,
    pId: 0,
    name: '音乐'
  },
  '3': {
    id: 3,
    pId: 1,
    name: '枪战片'
  },
  '4': {
    id: 4,
    pId: 2,
    name: '流行音乐'
  },
  '5': {
    id: 5,
    pId: 2,
    name: '古典音乐'
  }
};

// 根据id获取指定的数据
function getItemById(db, id){
  return db[id];
}

// 根据id获取当前层级的所有文件
function getChildrenById(db, id){
  const data = [];
  for(let key in db){
    const item = db[key];
    if(item.pId === id){
      data.push(item);
    }
  }
  return data;
}

// 根据指定的id找到当前这个文件以及它的所有的父级
function getAllParents(db, id){
  let data = [];
  const current = db[id];
  
  if(current){
    data.push(current);
    data = getAllParents(db, current.pId).concat(data);
  }
  
  return data;
}

// 根据指定id删除对应的数据以及它所有的子集
function deleteItemById(db, id){
  if(!id) return false;  // 根目录不能删除
  delete db[id];
  let children = getChildrenById(db, id);
  let len = children.length;
  if(len){
    for(let i=0; i<len; i++){
      deleteItemById(db, children[i].id);
    }
  }
  return true;
}













